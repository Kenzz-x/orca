declare -A config=(
  [version]="1.0.0"
  [lastUpd]="nov 23 2026"
)

nl()  { echo; }
clr() {
  local text="$1" c="$2"
  local r=255 g=255 b=255
  case "$c" in
    r|white)    r=255 g=255 b=255 ;;
    lime|green) r=0   g=255 b=0   ;;
    blue)       r=0   g=120 b=255 ;;
    red)        r=255 g=60  b=60  ;;
    yellow)     r=255 g=255 b=0   ;;
    cyan)       r=170 g=170 b=255 ;;
    magenta)    r=255 g=0   b=255 ;;
    orange)     r=255 g=140 b=0   ;;
    dgrey)      r=50  g=50  b=50  ;;
    grey|gray)  r=120 g=120 b=120 ;;
  esac
  printf '\033[38;2;%d;%d;%dm%s\033[0m' "$r" "$g" "$b" "$text"
}

clm() { clr '# ' cyan; clr "$1" r; clr ' : ' grey; clr "$2" r; nl; }
try() {
  "$@" || {
    local code=$?
    clr "orca: error ($code)" gray; nl
    return "$code"
  }
}

__prompt_git() {
    local b
    b=$(git symbolic-ref --short HEAD 2>/dev/null) \
      || b=$(git rev-parse --short HEAD 2>/dev/null)
    [[ -n $b ]] && printf ' \[\e[38;5;214m\](%s)\[\e[0m\]' "$b"
}

init() {
  PS1='\[\e[1;38;5;203m\]orca\[\e[0m\] \[\e[38;5;245m\]\w\[\e[0m\]$(__prompt_git)\n\[\e[1;38;5;118m\]~ $ \[\e[0m\]'
  clear
  bash ./logo.bash
  clr '———————— ' yellow; clr 'Available commands' r; clr ' ————————' yellow; nl
  clm 'orca -v' 'check orca version'
  clm 'orca py <file>' 'run python code'
  clm 'try <code>' 'run bash code'
  clm 'oc e' 'exit terminal'
  clm 'oc e <file>' 'copy file to downloads'
  clm 'oc b.rc' 'change .bashrc file'
  clm 'oc nv <title>' 'create new folder'
  clm 'oc rv <mjs> <out>' 'render video ffmpeg from js'
  clr 'Your terminal here:' gray; nl
  unset -f clm
  unset -f "$FUNCNAME"
}

orca() {
  local version="${config[version]}" lastUpd="${config[lastUpd]}"
  case "$1" in
    -v)
      echo "Orca $version ( $lastUpd )"
      ;;
    py)
      if [ -z "$2" ]; then
        clr 'orca: usage: orca py <file>' gray; nl
        return 1
      fi
      try python "$2"
      ;;
    *)
      clr 'orca: unknowed command' gray; nl
      return 127
      ;;
  esac
}


oc() {
  if [ "$1" = "b.rx" ]; then
    nano "~/.bashrc"
  elif [ "$1" = "e" ]; then
    exit
  elif [ "$1" = "c" ]; then
    cp "$2" "~/storage/downloads/"
  elif [ "$1" = "ch" ]; then
    cp "~/storage/downloads/" "$2"
  elif [ "$1" = "nv" ]; then
    mkdir "$2"
  elif [ "$1" = "rv" ]; then
    npx remolite render "$2" --out "$3"
  fi
}
init